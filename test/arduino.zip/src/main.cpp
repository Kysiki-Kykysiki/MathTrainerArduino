#include <Arduino.h>
#include "SPI.h"
#include "Adafruit_GFX.h"
#include "Adafruit_ILI9341.h"
#include "TempResistor.h"
#include "PhotoResistor.h"

void setup() {
    Serial.begin(9600);
    pinMode(13,OUTPUT);
    pinMode(2,INPUT);
    pinMode(3, OUTPUT);
}

float readDistance() {
  digitalWrite(3, LOW);
  delayMicroseconds(2);
  digitalWrite(3, HIGH);
  delayMicroseconds(10);
  digitalWrite(3, LOW);
  int duration = pulseIn(2, HIGH);
  return duration * 0.034 / 2;
}

PhotoResistor ph;

void loop() {
    float distance = readDistance();
    bool signal = distance < 10;
    bool is_dark = ph.get_PData() < 400;
    digitalWrite(13,is_dark);

    if(signal) Serial.println("Stop!");
}
